package com.example.perugamestournament;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    TextView contraseña;
    EditText txtCorreo, txtClave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCorreo = (EditText) findViewById(R.id.idCorreo);
        txtClave = (EditText) findViewById((R.id.idClave));
        contraseña = (TextView) findViewById(R.id.lnkClave);

        contraseña.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent contraseña = new Intent(MainActivity.this, RecuperarContrasena.class);
                startActivity(contraseña);
            }
        });

    }

    private boolean validacionCorreo(){
        String correo = txtCorreo.getText().toString();

        if (correo.isEmpty()){
            txtCorreo.setError("Falta colocar correo");
            return false;
        }else if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()){
            txtCorreo.setError("Correo incorrecto");
            return false;
        }else {
            txtCorreo.setError(null);
            return true;
        }
    }

    public void Ingresar (View view){
        String clave = txtClave.getText().toString();

        String msg = "";

        if (!validacionCorreo()){
            msg = "Observación en Correo";
            Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
        }
        else {
            if (clave.length() <= 7){
                msg = "La contraseña debe tener mínimo 8 digitos";
                Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
            }
            else {
                /*Intent ingresar = new Intent(this, EventosDisponibles.class);
                startActivity(ingresar);*/
                Intent intencion = new Intent(getApplicationContext(),MenuSlide2Activity.class);
                startActivity(intencion);
            }
        }
    }

    public void Registrar (View view) {
        Intent registro = new  Intent(this, Registrar.class);
        startActivity(registro);
    }

}
