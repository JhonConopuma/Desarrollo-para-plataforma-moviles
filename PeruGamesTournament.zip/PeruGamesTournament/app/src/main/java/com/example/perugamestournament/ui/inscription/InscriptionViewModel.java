package com.example.perugamestournament.ui.inscription;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class InscriptionViewModel extends ViewModel{

    private MutableLiveData<String> mText;

    public InscriptionViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
