package com.example.perugamestournament;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CrearEvento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_evento);
    }
}
